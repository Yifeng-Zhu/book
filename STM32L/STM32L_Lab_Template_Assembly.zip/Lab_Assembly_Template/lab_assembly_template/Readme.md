%
% Spring 2015
% Lab Assignment 
% ECE 271 Microcomputer Architecture and Applications
% Instructor: Prof. Yifeng Zhu
% Electrical and Computer Engineering
% University of Maine
% https://gitlab.eece.maine.edu/
%

Student Name
-------------------------------------------------

Lab Status Summary
-------------------------------------------------


Something Cool Implemented in This Lab
-------------------------------------------------


Sugguestions for This Lab
-------------------------------------------------


Typos, Errors, or Comments of The Textbook
-------------------------------------------------


Lab Credit
-------------------------------------------------
Did you received any help from someone other than 
Professor Zhu and lab assistants?



Academic Dishonesty
-------------------------------------------------
Academic dishonesty includes cheating, plagiarism
and all forms of misrepresentation in academic work, 
and is unacceptable at The University of Maine. As 
stated in the University of Maine's online 
undergraduate "Student Handbook," plagiarism 
(the submission of another's work without appropriate 
attribution) and cheating are violations of The 
University of Maine Student Conduct Code. An 
instructor who has probable cause or reason to 
believe a student has cheated may act upon such evidence, 
and should report the case to the supervising faculty 
member or the Department Chair for appropriate action.

